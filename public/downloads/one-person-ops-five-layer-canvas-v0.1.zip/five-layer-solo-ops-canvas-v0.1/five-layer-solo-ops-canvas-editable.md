# The Five-Layer Solo Ops Canvas

Define the workflow before choosing the tools.

## 1. Trigger

- Starting event:
- Detection method:
- Duplicate prevention:

## 2. Inputs

- Required inputs:
- Freshness rule:
- Missing-input behavior:

## 3. Preparation

- Reversible work to prepare:
- Output format:
- Tool or owner:

## 4. Approval

- Decision owner:
- Approval required for:
- Stop condition:

## 5. Verification

- Destination to inspect:
- Exact success signal:
- Evidence to retain:
- Recovery action:

## Boundary test

If a wrong action would be hard to reverse or materially affect another person, place it behind approval or a human handoff.

## Operating rule

Automate preparation. Keep authority explicit. Verify the destination before reporting success.

One Person Ops - Version 0.1
